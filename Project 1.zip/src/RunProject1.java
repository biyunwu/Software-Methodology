/**
 * Entry class which is going to run the project.
 * @author Anthony Triolo and Biyun Wu
 */

public class RunProject1 {
	public static void main(String[] args) {
		new Shopping().run();
	}
}
